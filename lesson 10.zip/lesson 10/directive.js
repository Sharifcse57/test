angular.module('Lession9')
.directive('headerView',function(){
	return {
		templateUrl:'header.html'
	}
});